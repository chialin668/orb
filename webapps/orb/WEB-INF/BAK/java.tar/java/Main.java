
public final class Main {

	public static void main(String[] args) {
		Test t = new Test("Java");
		Test t2 = new Test("C++");

		t.start();
		t2.start();
	}
}
