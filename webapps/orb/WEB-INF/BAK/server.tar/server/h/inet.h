#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERV_TCP_PORT 3341
#define SERV_HOST_ADDR "192.168.1.10"

#define MAXLINE 512

char *pname;
