#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include <sys/errno.h>
extern int errno;

#define MKEY1 1234L
#define MKEY2 2345L

#define PERMS 0666
