#define MAXMESGDATA (4096-16)

#define MESGHDRSIZE (sizeof(Mesg)-MAXMESGDATA)

typedef struct {
int len;
long type;
char data[MAXMESGDATA];
} Mesg;
