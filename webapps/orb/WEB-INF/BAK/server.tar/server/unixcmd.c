#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

unixCmd(char *retStr, char *cmd) {

	char inname[1024], outname[1024];
	pid_t pid;
	FILE *fp;
	char cmdStr[1024];
	char buff[1024];

	strcpy(inname, "/tmp/cmd");
	strcpy(outname, inname);
	strcat(outname, ".out");

	// create the command shell script
        if ((fp=fopen(inname, "wb")) == NULL)
                puts("error creating tmp file");

        strcpy(cmdStr, cmd);
        strcat(cmdStr, " > ");
        strcat(cmdStr, outname);
	fputs(cmdStr, fp);

	if ((fclose(fp)) == EOF)
		puts("error closing the file");

	// execute the command
	if ((chmod(inname, S_IRWXU)) == -1)
		puts("error changing the mode on the script");

	if ((pid = fork()) < 0) 
		puts("fork error");
	else if (pid == 0) {
		// child
	        if (execlp(inname, inname,
	                        (char *) 0) < 0)
	                puts("execlp error");
	}

	if (waitpid(pid, NULL, 0) < 0)
		puts("wait error");

	// reading the output	
        if ((fp=fopen(outname, "r")) == NULL)
                puts("error opening tmp file");

	while (fgets(buff, sizeof(buff), fp) != NULL) {
		//printf("%s", buff);
		strcat(retStr, buff);
	}

	if ((fclose(fp)) == EOF)
		puts("error closing the file");
}

/*

main() {

	char buffer[40960];

	
	unixCmd(buffer, "df -k");
	puts(buffer);
	//unixCmd(buffer, "iostat", "-nx 5 2");
}

*/
