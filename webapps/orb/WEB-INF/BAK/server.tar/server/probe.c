char *copyright = "Copyright (c)";

#include "./h/os.h"
#include "./h/top.h"
#include "./h/machine.h"

#include <signal.h>
#include <setjmp.h>
#include <ctype.h>
#include <sys/time.h>

/* external functions */
char *username();
char *itoa7();
time_t time();

char *myname = "top";
caddr_t get_process_info();
extern int (*proc_compares[])();
static char procstates_buffer[1024];
static void summary_format();

#define BUFFERSIZE	2048
char stdoutbuf[BUFFERSIZE];
extern int proc_compare();

int i_loadave();
int u_loadave();
int i_procstates();
int u_procstates();
int i_cpustates();
int u_cpustates();
int i_memory();
int u_memory();
int i_message();
int u_message();
int i_header();
int u_header();
int i_process();
int u_process();

/* pointers to display routines */
int (*d_loadave)() = i_loadave;
int (*d_procstates)() = i_procstates;
int (*d_cpustates)() = i_cpustates;
int (*d_memory)() = i_memory;
int (*d_message)() = i_message;
int (*d_header)() = i_header;
int (*d_process)() = i_process;


probe(char *retPtr, char *psPtr, struct statics statics) {

   register int count, i;
   register int num;
   register char *thisname;
   register char **procstate_names;
   register char **cpustate_names;
   register char **memstate_names;
   register int *procstates;
   register int *cpustates;
   register int *memstates;
   register int value;

   caddr_t processes;
   char nameBuff[1024];
   struct process_select ps;
   int order_index = 0;
   char *(*get_userid)() = username;
   struct system_info system_info;

   char buffer[1024];



    ps.idle    = 1;
    ps.system  = 0;
    ps.uid     = -1;
    ps.command = NULL;


   get_system_info(&system_info);

   processes = get_process_info(&system_info,
                                 &ps,
                                 proc_compares[order_index]);


    /* display the load averages */
    strcpy(retPtr, "<?xml version=\"1.0\" ?>");
    strcat(retPtr, "<probe>");

    strcat(retPtr, "<loadaverage>");
	/** usr **/
	strcat(retPtr, "<usr>");
	sprintf(buffer, "%5.2f", system_info.load_avg[0]);
	strcat(retPtr, buffer);
	strcat(retPtr, "</usr>");

	/** sys **/
        strcat(retPtr, "<sys>");
        sprintf(buffer, "%5.2f", system_info.load_avg[1]);
        strcat(retPtr, buffer);
        strcat(retPtr, "</sys>");

	/** wait for io **/
        strcat(retPtr, "<wt>");
        sprintf(buffer, "%5.2f", system_info.load_avg[2]);
        strcat(retPtr, buffer);
        strcat(retPtr, "</wt>");
    
   strcat(retPtr, "</loadaverage>");

   /* display process state breakdown */
   strcat(retPtr, "<processes>");
   strcat(retPtr, "<totalprocesses>");
   sprintf(buffer, "%d", system_info.p_total);
   strcat(retPtr, buffer);
   strcat(retPtr, "</totalprocesses>");

   procstate_names = statics.procstate_names;
   procstates = system_info.procstates;

   while ((thisname = *procstate_names++) != NULL) {
	num = *procstates++;

	if (*thisname != '\0') {

	   strcpy(nameBuff, thisname);
	   removeChar(nameBuff, ' ');
	   removeChar(nameBuff, ',');

	   sprintf(buffer, "<%s>%d</%s>", 
		nameBuff, 
		num, 
		nameBuff);
	   strcat(retPtr, buffer);
	}
    }
   
   strcat(retPtr, "</processes>");

   /* display the cpu state percentage breakdown */
   strcat(retPtr, "<cpu>");
   cpustate_names = statics.cpustate_names;
   cpustates = system_info.cpustates;

    while ((thisname = *cpustate_names++) != NULL) {
        if (*thisname != '\0') {
            /* retrieve the value and remember it */
            value = *cpustates++;

	    sprintf(buffer, "<%s>%4.1f%</%s>", 
			thisname, 
			((float)value)/10,
			thisname);
	    strcat(retPtr, buffer);
        }
    }

   strcat(retPtr, "</cpu>");

   /* display memory stats */
   strcat(retPtr, "<memory>");
   memstate_names = statics.memory_names;
   memstates = system_info.memory;

   while ((thisname = *memstate_names++) != NULL) {
        if (*thisname != '\0') {
           num = *memstates++;

           strcpy(nameBuff, thisname);
           removeChar(nameBuff, 'K');
           removeChar(nameBuff, ' ');
           removeChar(nameBuff, ',');

           sprintf(buffer, "<%s>%d</%s>", 
			nameBuff, 
			num, 
			nameBuff);
	   strcat(retPtr, buffer);
        }
    }


   strcat(retPtr, "</memory>");

	strcpy(psPtr, "<psstat>");
	for (i=0;i<20;i++) { 
		strcat(psPtr, "<ps>");
		strcat(psPtr, format_next_process(processes, get_userid));
		strcat(psPtr, "</ps>");
//		strcat(psPtr, "\n");
	}
	strcat(psPtr, "</psstat>");

   strcat(retPtr, psPtr);

   strcat(retPtr, "</probe>");
   
}


/*
main() {

	int i;
	char buff[1024];
	char psBuffer[10240];
	struct statics statics;

   	if (machine_init(&statics) == -1) {
        	puts("error!!");
   	}


    // something used by processes
    init_termcap(2);
    display_init(&statics);


	for (i=0;i<10;i++) {

		probe(buff, psBuffer, statics);

		puts(buff);
		puts(psBuffer);
	
		sleep(5);
	
	}
}

*/
