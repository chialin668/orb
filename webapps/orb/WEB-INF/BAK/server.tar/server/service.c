#include "./h/top.h"
#include "./h/machine.h"

#define MAXLINE 40960

int socketreadline(fd, ptr, maxlen)
register int fd;
register char *ptr;
register int maxlen;
{
        int n, rc;
        char c;
        for (n=1; n<maxlen; n++) {
                if ((rc = read(fd, &c, 1)) == 1) {
                        *ptr++ = c;
                        if (c == '\n')
                                break;
                } else if (rc == 0) {
                        if (n == 1)
                                return(0);
                        else
                                break;
                } else
                        return(-1);
        }
        *ptr = 0;
        return(n);
}

service(sockfd)
int sockfd;
{
        int i, n;
	static int flag = 0;
        char line[MAXLINE];
	char outBuff[MAXLINE];
	char psBuff[MAXLINE];
	char *command;
        struct statics stat;


        for (; ;) {
                n = socketreadline(sockfd, line, MAXLINE);
                if (n == 0)
                        return;

                else if (n < 0)
                        puts("service: read line error");

		n = strlen(line);

		line[n-1] = '\00';
		
		// print out the command 
		printf("command: |%s|\n", line);
//		bzero((char *) &outBuff, sizeof(outBuff));

		if (strcmp(line, "top") == 0) {

			if (!flag) {
				if (machine_init(&stat) == -1) {
                			puts("error machine_init()!!");
               			}

		    		// something used by processes detail
    				init_termcap(2);
    				display_init(&stat);
			}

			flag = 1;
			probe(outBuff, psBuff, stat);

		} else if (strncmp(line, "unix", 4) == 0) {

                	command = line + 5;
                	puts(command);
			
			unixCmd(outBuff, command);
			replaceChar(outBuff, '\n', '|');
//        		puts(outBuff);

		} else {
			puts("Wrong command");
			strcpy(outBuff, "Wrong command");
		}

		// return the result 
	        n = strlen(outBuff);
                outBuff[n] = '\n';

                if (write(sockfd, outBuff, n+1) != n+1)
                	puts("service: write line error");
        }
}

