#include <signal.h>
#include "./h/inet.h"

main(argc, argv) 
int argc;
char *argv[];
{
	int sockfd, newsockfd, clilen, childpid, gchildpid;
	struct sockaddr_in cli_addr, serv_addr;

	pname = argv[0];

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
		puts("server: can't open stream socket");

	bzero ((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(SERV_TCP_PORT);

	if (bind(sockfd, 
		(struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
		puts("server: can't bind local address");

	listen(sockfd, 5);

	for (; ;) {
		clilen = sizeof(cli_addr);
		newsockfd = accept(sockfd, 
				(struct sockaddr *)
				&cli_addr, 
				&clilen);
		if (newsockfd < 0) 
			puts("server: accept error");
		
		if ((childpid = fork()) < 0) 
			puts ("server: fork error");
		else if (childpid == 0) {

			close(sockfd);

			/* grand child */
			if ((gchildpid = fork()) < 0) 
				puts("server: fork error for gchild");
			else if (gchildpid == 0) {
			
				service(newsockfd);
				exit(0);

			} else {
				exit(0);
			}
			   
		}
		if (waitpid(childpid, NULL, 0) != childpid)
			puts ("wait child error");
		close(newsockfd);
	}
}
		
		
