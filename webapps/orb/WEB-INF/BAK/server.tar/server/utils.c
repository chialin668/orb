removeChar(char *inBuffer, char chkChar) {

	int i, n;
	char *dest, *src, tmpBuff[40960];

	src = inBuffer;
	dest = tmpBuff;

	n = strlen(src);

	for (i=0;i<n;i++) {
		if (*src != chkChar) {
			*dest = *src;
			dest++;
		}
		src ++;
	}

	*dest = '\00';

	strcpy(inBuffer, tmpBuff);
}

replaceChar(char *inBuffer, char chkChar, char repChar) {
        int i, n;
        char *ptr;

        ptr = inBuffer;
        n = strlen(inBuffer);

        for (i=0;i<n;i++) {
                if (*ptr == chkChar)
                        *ptr = repChar;
                ptr ++;
        }
}


char toUpperCase(char c) {
        if (c > 96 && c < 123)
                c -= 32;
	return c;
}

char toLowerCase(char c) {
        if (c > 64 && c < 91)
                c += 32;
        return c;
}


